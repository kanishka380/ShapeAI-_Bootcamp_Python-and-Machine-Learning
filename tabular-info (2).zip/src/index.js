import React from 'react';
import ReactDOM from 'react-dom';
import Grid from '@material-ui/core/Grid';
import Box from '@material-ui/core/Box';
import Divider from '@material-ui/core/Divider';
import Typography from '@material-ui/core/Typography';
import './styles.css';

const BalanceLine = () => {
  return (
    <Box display="flex" justifyContent="space-between" m={3}>
      <Typography variant="caption2">Saldo disponível</Typography>
      <Typography variant="caption2">R$ 1000</Typography>
    </Box>
  );
};

function App() {
  return (
    <Box width={1}>
      <BalanceLine />
      <BalanceLine />
      <Grid item xs={12}>
        <Divider />
      </Grid>
      <BalanceLine />
    </Box>
  );
}

const rootElement = document.getElementById('root');
ReactDOM.render(<App />, rootElement);
